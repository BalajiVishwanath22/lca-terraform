exports.handler = async (event, context) => {
  console.log(event);

  const allowed_domains = (
    process.env?.ALLOWED_SIGNUP_EMAIL_DOMAINS
    .split(",").map(domain => domain.trim())
  );

  if (event.triggerSource === 'PreSignUp_ExternalProvider') {
    const customEmailAlias = event.request?.userAttributes?.['custom:email_alias'] || '';
    const userName = event.userName || '';
    const parts = userName.split('_');
    const emailFromUsername = parts.slice(1).join('_');

    const email = customEmailAlias || emailFromUsername;

    if (email && email.includes('@')) {
      const emailDomain = email.split('@')[1];
      if (allowed_domains.includes(emailDomain)) {
        event.response.autoConfirmUser = true;
        event.response.autoVerifyEmail = true;
        return event;
      } else {
        throw new Error('Invalid email address domain');
      }
    }
    throw new Error('Unable to determine email from SSO username');
  }

  // PreAuthentication - for SAML users, use custom:email_alias instead of email
  const userAttributes = event.request?.userAttributes || {};
  const email = userAttributes['custom:email_alias'] || userAttributes['email'] || '';

  if (!email || !email.includes('@')) {
    throw Error('Username does not exist or invalid email address');
  }

  const emailDomain = email.split('@')[1];
  if (!emailDomain || !allowed_domains) {
    throw new Error('Server error - invalid configuration');
  }

  if (!allowed_domains.includes(emailDomain)) {
    throw new Error('Invalid email address domain');
  }

  return event;
};
